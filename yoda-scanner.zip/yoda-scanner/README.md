# 📈 Yoda Pattern Scanner

Professional Stock Analysis Dashboard with Automatic Target Detection, Risk/Reward Analysis, and Pattern Recognition.

## 🚀 Features

- **Smart Targets**: Automatic price targets from resistance levels, Fibonacci extensions, and swing highs
- **Risk Analysis**: Calculated stop losses and Risk/Reward ratios for every opportunity
- **Pattern Recognition**: Trendline breakouts, double bottoms, and more
- **MACD & Yoda Indicators**: Multi-timeframe signal analysis
- **Stock Presets**: Pre-configured watchlists by price range ($0-10, $10-50, $50-100, $100+)
- **Deduplication**: Shows only the best opportunity per symbol

## 📦 Stock Presets Included

| Preset | Description | Stocks |
|--------|-------------|--------|
| 💎 $100+ Stocks | High-priced stocks | ~712 |
| 💰 $50-$100 Stocks | Mid-high priced stocks | ~627 |
| 📊 $10-$50 Stocks | Mid-priced stocks | ~2,479 |
| 🎯 $0-$10 Stocks | Low-priced stocks | ~2,704 |
| 🔝 Top Tech | Major tech companies | 24 |

## 🐳 Docker Deployment

### Quick Start

```bash
# Clone or download this directory
cd yoda-scanner

# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Access the application
open http://localhost:8501
```

### Manual Docker Build

```bash
# Build the image
docker build -t yoda-scanner:latest .

# Run the container
docker run -d \
  --name yoda-pattern-scanner \
  -p 8501:8501 \
  -v $(pwd)/data:/app/data:ro \
  yoda-scanner:latest
```

### Docker Commands

```bash
# Stop the container
docker-compose down

# Rebuild after code changes
docker-compose up -d --build

# View container status
docker-compose ps

# Enter container shell
docker exec -it yoda-pattern-scanner /bin/bash

# View resource usage
docker stats yoda-pattern-scanner
```

## 🔧 Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `STREAMLIT_SERVER_PORT` | 8501 | Application port |
| `STREAMLIT_SERVER_ADDRESS` | 0.0.0.0 | Bind address |
| `TZ` | America/New_York | Timezone |

### Resource Limits (docker-compose.yml)

Uncomment the `deploy` section to enable resource limits:

```yaml
deploy:
  resources:
    limits:
      cpus: '2'
      memory: 4G
```

## 📁 Directory Structure

```
yoda-scanner/
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── requirements.txt
├── scanBreakout.py
├── README.md
└── data/
    ├── stocks_100_and_above.csv
    ├── stocks_50_to_100.csv
    ├── stocks_10_to_50.csv
    └── stocks_0_to_10.csv
```

## 🔄 Updating Stock Presets

The data directory is mounted as a volume, so you can update CSV files without rebuilding:

```bash
# Update a preset file
cp new_stocks.csv data/stocks_100_and_above.csv

# The app will use the new file on next scan
```

CSV Format:
```csv
Symbol,Last_Price,Industry,Sector
AAPL,185.50,Consumer Electronics,Technology
MSFT,420.30,Software - Infrastructure,Technology
```

## 🖥️ Dashboard Tabs

1. **🎯 Creative Dashboard** - Visual opportunity cards with sector grouping
2. **📱 Flash Cards** - Quick overview with mini charts
3. **⚖️ Risk/Reward & Upside** - Best risk/reward and upside potential analysis
4. **🏆 Rankings** - Scored rankings of all opportunities
5. **🎯 Confirmed** - Confirmed breakout signals
6. **⏳ Potential** - Approaching breakout setups
7. **📊 Full Analysis** - Complete data table

## 🔍 Scanning Filters

- **SELL Signal Exclusion**: Stocks with SELL signals in daily/weekly are automatically excluded
- **MACD Filter**: Only shows opportunities with positive or rising MACD
- **Yoda BUY Signal**: Requires BUY state from Yoda indicator
- **Trend Health**: Checks position relative to SMAs

## 📊 Technical Requirements

- Docker 20.10+
- Docker Compose 2.0+
- 2GB+ RAM recommended
- Internet access for yfinance data

## 🛠️ Troubleshooting

### Container won't start
```bash
# Check logs
docker-compose logs yoda-scanner

# Verify port is available
lsof -i :8501
```

### Slow scanning
- Use "Limit to first 50 symbols" option for large presets
- Consider scanning during market hours for faster data

### Data not loading
- Ensure CSV files are in the `data/` directory
- Check file permissions
- Verify CSV format matches expected columns

## 📝 License

MIT License - Feel free to modify and distribute.

## 🙏 Credits

- **yfinance** - Yahoo Finance data
- **Streamlit** - Web framework
- **Plotly** - Interactive charts
